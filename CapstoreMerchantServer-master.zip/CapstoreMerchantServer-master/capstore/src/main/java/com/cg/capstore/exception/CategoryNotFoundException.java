package com.cg.capstore.exception;

public class CategoryNotFoundException extends Exception{

	public CategoryNotFoundException() {
		super();
	}
	
	public CategoryNotFoundException (String message){
		super(message);
	}

	
}		
	







	
	

