package com.cg.capstore.exception;

public class OrderDetailsNotFoundException extends Exception {

	public OrderDetailsNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
