package com.cg.capstore.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.capstore.bean.PromosBean;

public interface PromoRepository extends JpaRepository<PromosBean, String>{

}
